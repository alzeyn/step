import React from 'react'
import ReactDOM from 'react-dom/client'
import StepCode from './StepCode.jsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <StepCode />
  </React.StrictMode>,
)
